<?php 
/*
 * Template Name: Front Page
 */
global $global_page_layout;
$global_page_layout = 'true-full';
get_template_part( 'page' );