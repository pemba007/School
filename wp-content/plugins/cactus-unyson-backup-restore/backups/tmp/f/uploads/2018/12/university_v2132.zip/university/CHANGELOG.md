UNIVERSITY RELEASE LOGS

University 2.1.3.2 (2018-07-19)
#Update: Visual Composer 5.5.2; Revolution Slider 5.4.8

University 2.1.3.1 (18th June 2018)
#Update: update Sample Data package
#Update: support WooCommerce 3.4
#Fix: Posts Grid shortcode disappears when resizing browser
#Fix: some warning errors

University 2.1.3 (30th Mar 2018)
includes U-Shortcodes 2.0.21
#Fix: Event Calendar shortcode does not work
#Fix: Event Start Date is compared with UTC time, not local server time
#Fix: Testimonial auto scroll does not work
#Update: show Department in hierarchical layout in Single Member page
University 2.1.2 (27th Mar 2018)
#Update: Visual Composer 5.4.7; Revolution Slider 5.4.7
University 2.1.2 (7th Mar 2018)
#Fix: some WooCommerce template bugs
University 2.1.1 (6th Mar 2018)
#Update: support WooCommerce 3.3.3
University 2.1 (13th Feb 2018)
#Fix: some CSS issues
#Update: RTL layout
#Update: better One Click Sample Data feature
University 2.0.25 (26th Dec 2017)
includes U-Course 1.14.4.1; U-Event 1.14.4.1; U-Member 1.13.2.4; U-Project 1.10.4.3; University Child Theme 1.0.2
#Update: support WooCommerce 3.2.6
#fixed: conflict in admin with Woo Membership add-on
#Fix: Input Textbox in Color Picker is hidden
#Fix: bugs in Cart & Checkout page of WooCommerce
University 2.0.24 (25th Nov 2017)
includes Visual Composer 5.4.5;
#Fix: support WooCommerce 3.2.5
#Fix: cannot click on Minus button in Cart page
University 2.0.23 (4th Oct 2017)
includes Visual Composer 5.3; Revolution Slider 5.4.6; U-Course 1.14.4; U-Event 1.14.4; U-Member 1.13.2.3; U-Project 1.10.4.3
#Update: option to Course Search feature: search keyword in Course Title only
#Fix: negative value of Event Duration in Member page if End Date is empty
#Fix: conflict with WooCommerce Subscription add-on
#Fix: Product Reviews do not appear if Rating is disabled
#Fix: notice messages
#Fix: cannot save Start Date of Course if Date Format is not English
University 2.0.22 (22nd July 2017)
includes Visual Composer 5.2; U-Event 1.14.3; U-Course 1.14.3
#Update: support WooCommerce 3.1.1
#Update: add shortcode Events List Table
#Update: add a filter to modify arguments of Courses List Table shortcode
University 2.0.21 (21st June 2017)
includes Revolution Slider 5.4.5.1; U-Event 1.14.2.2; U-Course 1.14.2.2; U-Project 1.10.5.1; U-Member 1.13.2.2;
#Update: support WooCommerce 3.0.8
#Fix: support Navigation Sidebar to replace Main Navigation
#Fix: cannot select products in Coupons or Orders admin screen of WooCommerce
#Fix title of archives page uses first post’s title
#Fix CSS for dropdown language menu on Main Navigation
University 2.0.20.1 (21st April 2017)
#Update: Support WooCommerce 3.0.3
#Fix: Related Products section breaks the page
Click here for full release logs