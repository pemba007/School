<?php
/* Include custom widgets file here
 *
 * Should be placed in \inc\widgets\ folder
 */
include('widgets/divider.php');
include('widgets/latest-post-type.php');
?>