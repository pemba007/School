<div class="event-listing event-listing-classic">
	<?php
	//loop here
	get_template_part('u-event/classic','list-item');
	?>
</div><!--/event-listing-->