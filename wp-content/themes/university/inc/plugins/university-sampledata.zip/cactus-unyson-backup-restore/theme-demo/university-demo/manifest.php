<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
$manifest = array();
$manifest['title'] = esc_html__( 'Main Demo', 'university' );
$manifest['screenshot'] = 'http://university.cactusthemes.com/wp-content/themes/university/screenshot.png';
$manifest['preview_link'] = 'http://university.cactusthemes.com/';
$manifest['demo_link'] = 'http://university.cactusthemes.com/demo/sample-data.zip';